"""Download and screen official HuMMANet v3 study bundles without joining studies."""

import argparse
import csv
import hashlib
import json
import socket
import sys
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / ".deps"))
import rdata  # noqa: E402


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--zenodo-ip", help="Fallback IP for local DNS failure; TLS still verifies zenodo.org")
    args = parser.parse_args()
    if args.zenodo_ip:
        original_getaddrinfo = socket.getaddrinfo

        def resolve(host, port, *rest, **kwargs):
            return original_getaddrinfo(args.zenodo_ip if host == "zenodo.org" else host, port, *rest, **kwargs)

        socket.getaddrinfo = resolve

    record_id = 22799569
    request = urllib.request.Request(f"https://zenodo.org/api/records/{record_id}", headers={"User-Agent": "research-data-audit/1.0"})
    with urllib.request.urlopen(request, timeout=40) as response:
        record = json.load(response)
    assert record["id"] == record_id
    source_dir = ROOT / "sources" / "hummanet"
    source_dir.mkdir(parents=True, exist_ok=True)
    rows = []
    hashes = {}
    for item in sorted(record["files"], key=lambda entry: entry["key"]):
        name = item["key"]
        if not name.endswith(".rds") or name == "study_index.rds":
            continue
        expected = item["checksum"].removeprefix("md5:")
        target = source_dir / name
        if not target.exists():
            url = f"https://zenodo.org/records/{record_id}/files/{name}?download=1"
            with urllib.request.urlopen(url, timeout=90) as response, target.open("wb") as output:
                while block := response.read(1024 * 1024):
                    output.write(block)
        digest = hashlib.md5(target.read_bytes()).hexdigest()
        if digest != expected or target.stat().st_size != item["size"]:
            raise ValueError(f"checksum or size mismatch: {name}")
        hashes[name] = {"md5": digest, "bytes": item["size"]}
        bundle = rdata.read_rds(target, default_encoding="utf-8")
        metadata = bundle["MetadataProfile"]
        taxa = bundle["taxaAbundanceProfile"]
        metabolites = bundle["OriginalMetaboliteProfile"]
        shared = set(metadata["sample_id"]) & set(taxa["sample_id"]) & set(metabolites["sample_id"])
        def counts(column):
            if column not in metadata:
                return ""
            return " | ".join(f"{label}:{number}" for label, number in metadata[column].astype("string").fillna("NA").value_counts().items())
        rows.append({
            "study": name,
            "n_metadata": len(metadata),
            "n_unique_sample_id": metadata["sample_id"].nunique(dropna=True),
            "n_shared_three_tables": len(shared),
            "disease_clean": counts("diseaseCat_clean"),
            "disease_raw": counts("diseaseCat"),
            "microbiome_site": counts("body_site"),
            "metabolomics_site": counts("Metabolomics_body_site"),
            "n_taxa": len(taxa),
            "n_metabolites": len(metabolites),
        })
        print(name, rows[-1]["disease_clean"], rows[-1]["metabolomics_site"], flush=True)
    result_dir = ROOT / "results"
    with (result_dir / "hummanet_study_screen.csv").open("w", newline="", encoding="utf-8") as output:
        writer = csv.DictWriter(output, fieldnames=rows[0])
        writer.writeheader()
        writer.writerows(rows)
    (result_dir / "hummanet_download_audit.json").write_text(json.dumps({"record": record_id, "files": hashes}, indent=2), encoding="utf-8")
    assert len(rows) == 55 and all(row["n_metadata"] == row["n_unique_sample_id"] == row["n_shared_three_tables"] for row in rows)
    print("screened", len(rows), "study units")


if __name__ == "__main__":
    main()
