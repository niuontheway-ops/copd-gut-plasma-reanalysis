"""Render the seven separately audited public-cohort sample flows."""

import csv
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / ".deps"))

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch


OUT = ROOT / "results"


def audit(name):
    return json.loads((OUT / name).read_text(encoding="utf-8"))


def main():
    pilot = audit("audit.json")
    stool = audit("copd_stool_audit.json")
    bowerman = audit("bowerman_stool_audit.json")
    fev1 = audit("spiromics_fev1_audit.json")
    aecopd = audit("aecopd_paired_audit.json")
    xuq = audit("hummanet_xuq_gut_serum_audit.json")
    xuq_source = audit("xuq_original_source_audit.json")
    with (OUT / "copd_metabolites_adjusted.csv").open(newline="", encoding="utf-8") as handle:
        hippurate = next(row for row in csv.DictReader(handle) if row["metabolite"] == "hippurate")
    with (OUT / "copd_stool_genus_adjusted.csv").open(newline="", encoding="utf-8") as handle:
        stool_model = next(csv.DictReader(handle))
    with (OUT / "spiromics_fev1_metabolites_adjusted.csv").open(newline="", encoding="utf-8") as handle:
        fev1_model = next(csv.DictReader(handle))

    case = pilot["st001639"]["case"]
    control = pilot["st001639"]["control"]
    labelled = case + control
    assert labelled + pilot["st001639"]["excluded_missing_copd"] == pilot["st001639"]["matrix_samples"]
    assert stool["stool_copd_cases"] + stool["stool_controls"] == stool["stool_rows"]
    assert bowerman["bowerman_copd_n"] + bowerman["bowerman_control_n"] == bowerman["source_sample_columns"]
    assert aecopd["case_keys_exactly_match_all_omics"] is True
    assert xuq["paired_sample_ids"] == xuq_source["bundle_matched_source_metadata_and_plasma"]

    rows = [
        ("ST001639\nCOPD plasma", f'{pilot["st001639"]["matrix_samples"]} assay samples',
         f"{labelled} labelled: {case} COPD / {control} control",
         f'{hippurate["n_complete"]} hippurate model records'),
        ("Arivale\nstool + blood", f'{pilot["arivale"]["gut_rows"]} stool / {pilot["arivale"]["plasma_rows"]} blood IDs',
         f'{pilot["arivale"]["matched_rows"]} exact stool–blood pairs', "No public COPD outcome"),
        ("DATA2873\nCOPD stool", f'{stool["clinical_rows"]} clinical IDs',
         f'{stool["stool_rows"]} stool matches: {stool["stool_copd_cases"]} COPD / {stool["stool_controls"]} control',
         f'{stool_model["n_complete"]} COPD-contrast models\n{stool["fev1_complete_case_n"]} case-only FEV1% models'),
        ("Bowerman2020\nCOPD stool 16S", f'{bowerman["source_variant_rows"]} ASVs / {bowerman["source_sample_columns"]} samples',
         f'{bowerman["bowerman_copd_n"]} COPD / {bowerman["bowerman_control_n"]} healthy exact keys',
         f'{bowerman["bowerman_genera_tested"]} genera tested; {bowerman["bowerman_fdr_hits"]} FDR hits\nNo blood metabolites'),
        ("ST002088\nSPIROMICS plasma", f'{fev1["metabolite_samples"]} assay IDs',
         f'{fev1["clinical_samples"]} within-study clinical matches',
         f'{fev1_model["n_complete"]} FEV1 model records\nNo public COPD label'),
        ("AECOPD\nselected features", f'{aecopd["case_n"] + aecopd["control_n"]} clinical: {aecopd["case_n"]} cases / {aecopd["control_n"]} controls',
         f'{aecopd["case_n"]} cases with matching selected omics',
         f'{aecopd["metabolite_control_n"]} controls with metabolomics'),
        ("XuQ\nfamily cohort", f'{xuq["paired_sample_ids"]} stool–blood–metadata triads',
         f'{xuq_source["bundle_matched_source_metadata_and_plasma"]} original-source matches',
         f'{xuq["control_label_n"]} Control-labelled\n'
         f'{xuq_source["bacteroides_hippurate_source_adjusted"]["n"]} adjusted pair-model records'),
    ]

    fig, ax = plt.subplots(figsize=(15, 9.8))
    fig.patch.set_facecolor("white")
    ax.set_xlim(0, 15)
    ax.set_ylim(-0.8, 8.0)
    ax.axis("off")
    ax.text(0.2, 7.68, "Public cohort flow: within-study joins only", fontsize=17, weight="bold", color="#14263d")
    ax.text(0.2, 7.30, "Rows are different cohorts. No cross-row arrows or participant-level linkage are established.", fontsize=10.5, color="#43556b")
    colors = ("#e9f1f7", "#dcece7", "#f4eee1")
    for index, (name, first, second, third) in enumerate(rows):
        y = 6.45 - index * 1.02
        ax.text(0.2, y + 0.26, name, va="center", fontsize=10.5, weight="bold", color="#14263d")
        for x, label, color in zip((2.55, 6.55, 10.55), (first, second, third), colors):
            ax.add_patch(FancyBboxPatch((x, y - 0.08), 3.45, 0.73,
                                        boxstyle="round,pad=0.08,rounding_size=0.08",
                                        facecolor=color, edgecolor="#91a6b6", linewidth=0.8))
            ax.text(x + 1.725, y + 0.28, label, ha="center", va="center", fontsize=9.2,
                    color="#14263d", wrap=True)
        for x in (6.08, 10.08):
            ax.annotate("", xy=(x + 0.38, y + 0.28), xytext=(x, y + 0.28),
                        arrowprops={"arrowstyle": "->", "lw": 1.1, "color": "#62788a"})
    ax.text(0.2, -0.43, "XuQ has no verified COPD diagnosis; ST002088 is not external replication of ST001639. Counts are from audited outputs.",
            fontsize=9.3, color="#43556b")
    fig.savefig(OUT / "supplementary_figure_s2_cohort_flow.png", dpi=300, bbox_inches="tight")
    plt.close(fig)


if __name__ == "__main__":
    main()
