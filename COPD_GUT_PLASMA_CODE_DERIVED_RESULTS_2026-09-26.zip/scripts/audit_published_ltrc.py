"""Transcribe, but do not reanalyse, published LTRC hippurate estimates."""

import hashlib
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / ".deps"))

import openpyxl

SOURCE = ROOT / "sources/rosario2026_supplementary_tables.xlsx"
SHA256 = "31bd5fc31059d621b4b89f628ae1eec132636a777f8ab289c8074c0c7af1b215"
OUT = ROOT / "results/rosario2026_ltrc_aggregate_audit.json"


def main():
    assert hashlib.sha256(SOURCE.read_bytes()).hexdigest() == SHA256
    workbook = openpyxl.load_workbook(SOURCE, read_only=True, data_only=True)
    output = {"source_sha256": SHA256, "doi": "10.1007/s11306-026-02508-3",
              "scope": "published LTRC aggregate results, not individual-level reanalysis", "rows": {}}
    for sheet_name in ("ST 2", "ST 4"):
        sheet = workbook[sheet_name]
        assert sheet["C2"].value == "COPD vs Control"
        rows = []
        for row_index, row in enumerate(sheet.iter_rows(min_row=4, values_only=True), start=4):
            if row[0] == "Hippuric acid" and row[1] == "HMDB0000714":
                record = {"row": row_index, "name": row[0], "hmdb_id": row[1],
                          "odds_ratio": row[2], "ci95": row[3], "p": row[4], "fdr": row[5]}
                if sheet_name == "ST 4":
                    record["published_significance_label"] = row[6]
                rows.append(record)
        assert len(rows) == 2 and all(r["odds_ratio"] < 1 and r["fdr"] > 0.05 for r in rows)
        output["rows"][sheet_name] = rows
    OUT.write_text(json.dumps(output, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(f"Verified {sum(map(len, output['rows'].values()))} published aggregate entries; {OUT}")


if __name__ == "__main__":
    main()
