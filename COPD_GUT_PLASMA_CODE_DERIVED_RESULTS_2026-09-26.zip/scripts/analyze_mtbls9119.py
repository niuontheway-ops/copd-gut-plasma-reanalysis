"""Exploratory COPD exacerbation contrast in deposited MTBLS9119 serum data.

The 2024 paper's group-by-sex table conflicts with the deposited sample labels.
Results must not be treated as validation until that discrepancy is resolved.
"""

import csv
import hashlib
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / ".deps"))

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import statsmodels.api as sm
from statsmodels.stats.multitest import multipletests

SOURCE = ROOT / "sources"
OUT = ROOT / "results"
FILES = {
    "MTBLS9119_s_MTBLS9119.txt": "92f05a7ee0f1406f47f8d74131b5b96ae84e36066844063760e0bfcd5b2a5f13",
    "m_MTBLS9119_LC-MS_negative_reverse-phase_metabolite_profiling_v2_maf.tsv": "3f43eebf8469dde7a337e5fc2fd5e7e82a61164233968aaedaf121bbc1684819",
}
CANDIDATES = ("3-Indolepropionic acid", "Hippuric acid", "Indolelactic acid")


def tsv(path):
    with path.open(encoding="utf-8-sig", newline="") as stream:
        return list(csv.DictReader(stream, delimiter="\t"))


def main():
    for name, expected in FILES.items():
        assert hashlib.sha256((SOURCE / name).read_bytes()).hexdigest() == expected
    samples = [r for r in tsv(SOURCE / "MTBLS9119_s_MTBLS9119.txt")
               if r["Characteristics[Sample type]"] == "experimental sample"]
    ids = [r["Sample Name"] for r in samples]
    assert len(ids) == len(set(ids)) == 30
    assert {r["Factor Value[Cohort]"] for r in samples} == {"COPD-FE", "COPD-NE"}
    assert {r["Factor Value[Gender]"] for r in samples} == {"Male", "Female"}
    assert sum(r["Factor Value[Cohort]"] == "COPD-FE" for r in samples) == 15
    assert sum(r["Factor Value[Cohort]"] == "COPD-NE" for r in samples) == 15
    maf = tsv(SOURCE / "m_MTBLS9119_LC-MS_negative_reverse-phase_metabolite_profiling_v2_maf.tsv")
    assert all(i in maf[0] for i in ids)
    design = pd.DataFrame({
        "const": 1.0,
        "fe": [float(r["Factor Value[Cohort]"] == "COPD-FE") for r in samples],
        "female": [float(r["Factor Value[Gender]"] == "Female") for r in samples],
    }, index=ids)
    results = []
    for name in CANDIDATES:
        matching = [r for r in maf if r["metabolite_identification"] == name]
        assert len(matching) == 1, (name, len(matching))
        values = np.array([float(matching[0][i]) for i in ids])
        assert np.isfinite(values).all() and (values > 0).all()
        log2_values = np.log2(values)
        fit = sm.OLS(log2_values, design).fit(cov_type="HC3")
        lo, hi = fit.conf_int().loc["fe"]
        results.append({
            "metabolite": name,
            "database_identifier": matching[0]["database_identifier"],
            "n_fe": 15,
            "n_ne": 15,
            "fe_minus_ne_log2_adjusted_female": float(fit.params["fe"]),
            "ci95_low": float(lo),
            "ci95_high": float(hi),
            "p_hc3": float(fit.pvalues["fe"]),
            "fe_minus_ne_log2_unadjusted": float(log2_values[design.fe == 1].mean() - log2_values[design.fe == 0].mean()),
        })
    frame = pd.DataFrame(results)
    frame["q_BH_3"] = multipletests(frame.p_hc3, method="fdr_bh")[1]
    OUT.mkdir(exist_ok=True)
    frame.to_csv(OUT / "mtbls9119_serum_exacerbation.csv", index=False)
    audit = {
        "accession": "MTBLS9119",
        "source_sha256": FILES,
        "sample_type": "Serum (deposited sample table)",
        "experimental_samples": len(samples),
        "sample_table_qc_excluded": 6,
        "maf_qc_columns_excluded": 7,
        "groups_as_deposited": {"COPD-FE": 15, "COPD-NE": 15},
        "male_as_deposited": {"COPD-FE": 13, "COPD-NE": 11},
        "paper_table_i_male": {"COPD-FE": 11, "COPD-NE": 13},
        "group_sex_discrepancy_unresolved": True,
        "model": "OLS log2 peak area ~ deposited FE label + female; HC3 CI/P; BH across three measured prespecified candidates",
        "not_available_in_sample_table": ["age", "BMI", "smoking", "medication", "kidney function", "diet"],
        "not_copd_case_control_validation": True,
    }
    (OUT / "mtbls9119_serum_audit.json").write_text(json.dumps(audit, indent=2), encoding="utf-8")
    y = np.arange(len(frame))[::-1]
    fig, ax = plt.subplots(figsize=(7.2, 3.2))
    x = frame.fe_minus_ne_log2_adjusted_female.to_numpy()
    ax.errorbar(x, y, xerr=[x - frame.ci95_low, frame.ci95_high - x], fmt="o", capsize=3)
    ax.axvline(0, color="0.5", lw=1)
    ax.set(yticks=y, yticklabels=frame.metabolite, xlabel="FE - NE, adjusted log2 serum peak area (95% CI)")
    fig.tight_layout()
    fig.savefig(OUT / "figure7_mtbls9119_serum_exacerbation.png", dpi=180)
    plt.close(fig)
    print(frame.to_string(index=False))


if __name__ == "__main__":
    main()
