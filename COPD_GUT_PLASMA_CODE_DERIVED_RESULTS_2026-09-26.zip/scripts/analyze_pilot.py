"""Reproducible, explicitly cross-cohort exploratory analysis.

No subject linkage between the Arivale gut/plasma cohort and SPIROMICS COPD.
Run with the bundled Codex Python after installing requirements into ../.deps.
"""

from __future__ import annotations

import csv
import hashlib
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / ".deps"))

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import statsmodels.api as sm
from statsmodels.stats.multitest import multipletests


TARGETS = (
    "indolepropionate",
    "indoleacetate",
    "indolelactate",
    "p-cresol sulfate",
    "hippurate",
)
SOURCE = ROOT / "sources"
OUT = ROOT / "results"


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read_workbench_matrix(path: Path) -> tuple[pd.DataFrame, pd.Series]:
    with path.open(encoding="utf-8-sig", newline="") as handle:
        rows = list(csv.reader(handle, delimiter="\t"))
    samples = rows[0][1:]
    factors = pd.Series(rows[1][1:], index=samples)
    assert len(samples) == len(set(samples)), f"Repeated sample in {path.name}"
    assert all(len(row) == len(samples) + 1 for row in rows), path.name
    matrix = pd.DataFrame(
        {row[0]: pd.to_numeric(pd.Series(row[1:]), errors="coerce").to_numpy() for row in rows[2:] if row[0].strip()},
        index=samples,
    )
    return matrix, factors


def design(frame: pd.DataFrame, fields: list[str]) -> pd.DataFrame:
    missing = frame[fields].isna().any(axis=1)
    x = pd.get_dummies(frame[fields], drop_first=True, dtype=float)
    x.loc[missing, :] = np.nan
    return sm.add_constant(x, has_constant="add").astype(float)


def model(y: pd.Series, x: pd.DataFrame, term: str) -> dict:
    common = y.index.intersection(x.index)
    data = x.loc[common].copy()
    data["outcome"] = y.loc[common]
    data = data.replace([np.inf, -np.inf], np.nan).dropna()
    if len(data) < 50 or data[term].nunique() < 2:
        return {"n": len(data), "beta": np.nan, "lo": np.nan, "hi": np.nan, "p": np.nan}
    fit = sm.OLS(data.pop("outcome"), data).fit(cov_type="HC3")
    interval = fit.conf_int().loc[term]
    return {
        "n": len(common),
        "n_complete": int(fit.nobs),
        "beta": float(fit.params[term]),
        "lo": float(interval.iloc[0]),
        "hi": float(interval.iloc[1]),
        "p": float(fit.pvalues[term]),
    }


def zlog(values: pd.Series) -> pd.Series:
    v = pd.to_numeric(values, errors="coerce")
    logged = np.log2(v.where(v > 0))
    return (logged - logged.mean()) / logged.std(ddof=1)


def zlog_winsor(values: pd.Series) -> pd.Series:
    logged = np.log2(pd.to_numeric(values, errors="coerce").where(lambda v: v > 0))
    lo, hi = logged.quantile([0.01, 0.99])
    clipped = logged.clip(lo, hi)
    return (clipped - clipped.mean()) / clipped.std(ddof=1)


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    files = [SOURCE / f"ST001639-{id}.txt" for id in ("AN002681", "AN002682", "AN002683", "AN002684")]
    meta_file = SOURCE / "ST001639-samples.html"
    gut_file = SOURCE / "gibbons-bmf" / "gutmicrobiome.csv"
    plasma_file = SOURCE / "gibbons-bmf" / "metabolomics.csv"
    chemical_file = SOURCE / "gibbons-bmf" / "metabolomics_fullmetadata.csv"
    source_files = [*files, meta_file, gut_file, plasma_file, chemical_file]
    for path in source_files:
        if not path.is_file():
            raise FileNotFoundError(path)

    matrices = [read_workbench_matrix(path) for path in files]
    first_samples = list(matrices[0][0].index)
    for matrix, factor in matrices[1:]:
        assert set(matrix.index) == set(first_samples)
        assert factor.sort_index().equals(matrices[0][1].sort_index())
    features = pd.concat([matrix.reindex(first_samples) for matrix, _ in matrices], axis=1)
    assert not features.columns.duplicated().any(), "Duplicate Workbench metabolite names"
    assert set(TARGETS).issubset(features.columns)

    html_tables = pd.read_html(meta_file)
    sample_meta = next(table for table in html_tables if "Sample name" in table.columns)
    sample_meta = sample_meta.set_index("Sample name")
    assert sample_meta.index.is_unique
    assert set(first_samples).issubset(sample_meta.index)
    factors = matrices[0][1].str.split(":", n=1).str[-1]
    assert factors.loc[first_samples].fillna("NA").eq(sample_meta.loc[first_samples, "COPD"].fillna("NA")).all()
    clinical = sample_meta.loc[first_samples, ["COPD", "Sample_Data:Gender", "Race", "BMI", "Smoking Status"]].rename(
        columns={"Sample_Data:Gender": "sex", "Race": "race", "BMI": "bmi", "Smoking Status": "smoking"}
    )
    clinical["bmi"] = pd.to_numeric(clinical["bmi"], errors="coerce")
    clinical = clinical.loc[clinical["COPD"].isin(["case", "control"])].copy()
    clinical["copd"] = (clinical["COPD"] == "case").astype(int)
    plasma_missing = [{"segment": "ST001639", "field": field, "denominator": len(clinical),
                       "missing_or_nonpositive": int(clinical[field].isna().sum())}
                      for field in ["sex", "race", "bmi", "smoking"]]
    for name in TARGETS:
        values = pd.to_numeric(features.loc[clinical.index, name], errors="coerce")
        plasma_missing.append({"segment": "ST001639", "field": name, "denominator": len(clinical),
                               "missing_or_nonpositive": int((~(values > 0)).sum())})
    pd.DataFrame(plasma_missing).to_csv(OUT / "st001639_missingness.csv", index=False)
    baseline = []
    for label, group in clinical.groupby("COPD"):
        baseline.append({
            "group": label, "n": len(group), "male_n": int(group["sex"].eq("M").sum()),
            "female_n": int(group["sex"].eq("F").sum()),
            "bmi_mean": float(group["bmi"].mean()),
            "current_smoker_n": int(group["smoking"].eq("current smoker").sum()),
            "former_smoker_n": int(group["smoking"].eq("former smoker").sum()),
            "smoking_missing_n": int(group["smoking"].isna().sum()),
        })
    pd.DataFrame(baseline).to_csv(OUT / "st001639_baseline.csv", index=False)
    x_copd = design(clinical, ["copd", "sex", "race", "bmi", "smoking"])
    copd_rows = []
    for name in TARGETS:
        result = model(zlog(features.loc[clinical.index, name]), x_copd, "copd")
        copd_rows.append({"metabolite": name, **result})
    copd = pd.DataFrame(copd_rows)
    copd["q_bh_5"] = multipletests(copd["p"], method="fdr_bh")[1]
    copd.to_csv(OUT / "copd_metabolites_adjusted.csv", index=False)

    # Separate post hoc sensitivity: all estimable named features, not the five-candidate family.
    named_rows = []
    for name in features.columns:
        outcome = zlog(features.loc[clinical.index, name])
        complete = x_copd.assign(outcome=outcome).replace([np.inf, -np.inf], np.nan).dropna()
        if len(complete) < 50 or complete["copd"].nunique() < 2:
            named_rows.append({"metabolite": name, "status": "insufficient_complete_cases"})
        elif np.linalg.matrix_rank(complete[x_copd.columns].to_numpy()) < len(x_copd.columns):
            named_rows.append({"metabolite": name, "status": "rank_deficient_design"})
        else:
            result = model(outcome, x_copd, "copd")
            named_rows.append({"metabolite": name, "status": "ok" if np.isfinite(result["p"]) else "nonfinite_p", **result})
    named = pd.DataFrame(named_rows)
    estimable = named["status"].eq("ok")
    named.loc[estimable, "q_bh_named"] = multipletests(named.loc[estimable, "p"], method="fdr_bh")[1]
    assert len(named) == features.shape[1] and estimable.sum() >= len(TARGETS)
    for candidate in TARGETS:
        original = copd.set_index("metabolite").loc[candidate]
        expanded = named.set_index("metabolite").loc[candidate]
        assert np.isclose(original["p"], expanded["p"])
    named.to_csv(OUT / "st001639_all_named_sensitivity.csv", index=False)

    ranked = named.loc[estimable].sort_values("p").reset_index(drop=True)
    ranks = np.arange(1, len(ranked) + 1)
    bh_cutoff = 0.05 * ranks / len(ranked)
    assert not (ranked["p"].to_numpy() <= bh_cutoff).any()
    hippurate_rank = int(ranked.index[ranked["metabolite"].eq("hippurate")][0]) + 1
    fig, ax = plt.subplots(figsize=(6.8, 4.2))
    ax.plot(ranks, ranked["p"], color="#315f86", lw=1.5, label="Observed nominal P")
    ax.plot(ranks, bh_cutoff, color="#b0423c", ls="--", lw=1.5,
            label="BH 0.05 rank threshold")
    ax.scatter([hippurate_rank], [ranked.loc[hippurate_rank - 1, "p"]],
               color="#b0423c", zorder=3)
    hippurate_q = ranked.loc[hippurate_rank - 1, "q_bh_named"]
    ax.annotate(f"Hippurate: rank {hippurate_rank}, q={hippurate_q:.3f}",
                (hippurate_rank, ranked.loc[hippurate_rank - 1, "p"]),
                xytext=(17, 18), textcoords="offset points", fontsize=8,
                arrowprops={"arrowstyle": "-", "color": "#b0423c"})
    ax.set(xscale="log", yscale="log", xlabel=f"Rank among {len(ranked)} estimable features",
           ylabel="P value", title="No full-metabolome BH discovery in ST001639")
    ax.legend(fontsize=8, loc="lower right")
    fig.tight_layout()
    fig.savefig(OUT / "supplementary_figure_s3_st001639_multiplicity.png", dpi=300)
    plt.close(fig)

    sensitivity_rows = []
    strata = {
        "all": clinical.index,
        "former_smokers": clinical.index[clinical["smoking"].eq("former smoker")],
        "current_smokers": clinical.index[clinical["smoking"].eq("current smoker")],
        "male": clinical.index[clinical["sex"].eq("M")],
        "female": clinical.index[clinical["sex"].eq("F")],
        "white": clinical.index[clinical["race"].eq("White")],
    }
    for stratum, sample_ids in strata.items():
        subset = clinical.loc[sample_ids]
        fields = [field for field in ["copd", "sex", "race", "bmi", "smoking"] if subset[field].nunique() > 1]
        x = design(subset, fields)
        result = model(zlog(features.loc[sample_ids, "hippurate"]), x, "copd")
        sensitivity_rows.append({"stratum": stratum, "cases": int(subset.copd.sum()), "controls": int((1 - subset.copd).sum()), **result})
    winsor_result = model(zlog_winsor(features.loc[clinical.index, "hippurate"]), x_copd, "copd")
    sensitivity_rows.append({"stratum": "all_winsor_log_1_99", "cases": int(clinical.copd.sum()), "controls": int((1 - clinical.copd).sum()), **winsor_result})
    pd.DataFrame(sensitivity_rows).to_csv(OUT / "hippurate_sensitivity.csv", index=False)

    gut = pd.read_csv(gut_file, dtype={"public_client_id": str}).set_index("public_client_id")
    plasma = pd.read_csv(plasma_file, dtype={"public_client_id": str}).set_index("public_client_id")
    assert gut.index.is_unique and plasma.index.is_unique
    chemicals = pd.read_csv(chemical_file)
    chemical_ids = {
        name: str(chemicals.loc[chemicals["BIOCHEMICAL_NAME"].eq(name), "CHEMICAL_ID"].iloc[0])
        for name in TARGETS
    }
    assert set(chemical_ids.values()).issubset(plasma.columns)
    shared = gut.index.intersection(plasma.index)
    assert len(shared) == 456, f"Unexpected Arivale overlap: {len(shared)}"
    taxon_columns = [col for col in gut.columns if col.startswith("taxa_")]
    counts = gut.loc[shared, taxon_columns].astype(float)
    assert counts.notna().all().all() and (counts >= 0).all().all()
    rel = counts.div(counts.sum(axis=1), axis=0)
    keep = (rel.gt(0).mean() >= 0.20) & (rel.mean() >= 0.001)
    taxa = list(keep[keep].index)
    clr = np.log(counts[taxon_columns] + 0.5)
    clr = clr.sub(clr.mean(axis=1), axis=0)
    assert len(taxa) > 0
    base = gut.loc[shared, ["sex", "age", "BMI_CALC", "bowel", "eGFR"]].rename(columns={"BMI_CALC": "bmi", "eGFR": "egfr"})
    base["age"] = pd.to_numeric(base["age"], errors="coerce")
    base["bmi"] = pd.to_numeric(base["bmi"], errors="coerce")
    base["bowel"] = pd.to_numeric(base["bowel"], errors="coerce")
    base["egfr"] = pd.to_numeric(base["egfr"], errors="coerce")
    arivale_missing = [{"segment": "Arivale", "field": field, "denominator": len(base),
                        "missing_or_nonpositive": int(base[field].isna().sum())}
                       for field in ["sex", "age", "bmi", "bowel", "egfr"]]
    for name in TARGETS:
        values = pd.to_numeric(plasma.loc[shared, chemical_ids[name]], errors="coerce")
        arivale_missing.append({"segment": "Arivale", "field": name, "denominator": len(base),
                                "missing_or_nonpositive": int((~(values > 0)).sum())})
    pd.DataFrame(arivale_missing).to_csv(OUT / "arivale_missingness.csv", index=False)
    pd.DataFrame([{
        "n": len(base), "age_mean": float(base["age"].mean()),
        "bmi_mean": float(base["bmi"].mean()), "egfr_mean": float(base["egfr"].mean()),
        "female_n": int(base["sex"].eq("F").sum()),
    }]).to_csv(OUT / "arivale_baseline.csv", index=False)
    x_base = design(base, ["sex", "age", "bmi", "bowel", "egfr"])
    gut_rows = []
    for name in TARGETS:
        y = zlog(plasma.loc[shared, chemical_ids[name]])
        for taxon in taxa:
            x = x_base.copy()
            taxon_z = (clr[taxon] - clr[taxon].mean()) / clr[taxon].std(ddof=1)
            x["genus_clr_z"] = taxon_z
            result = model(y, x, "genus_clr_z")
            gut_rows.append({"metabolite": name, "taxon": taxon, **result})
    associations = pd.DataFrame(gut_rows)
    valid = associations["p"].notna()
    associations.loc[valid, "q_bh_all"] = multipletests(associations.loc[valid, "p"], method="fdr_bh")[1]
    associations.to_csv(OUT / "gut_plasma_adjusted.csv", index=False)

    fig, ax = plt.subplots(figsize=(7, 3.4))
    y_pos = np.arange(len(copd))
    ax.errorbar(copd["beta"], y_pos, xerr=[copd["beta"] - copd["lo"], copd["hi"] - copd["beta"]], fmt="o", capsize=3)
    ax.axvline(0, color="grey", lw=1)
    ax.set_yticks(y_pos, copd["metabolite"])
    ax.invert_yaxis()
    ax.set_xlabel("Adjusted standardized plasma difference: COPD minus control (95% CI)")
    ax.set_title("SPIROMICS ST001639 — exploratory, no age adjustment")
    fig.text(0.5, 0.015, "Hippurate: q=0.042 among 5 candidates; q=0.997 across 985 named features (post hoc)",
             ha="center", fontsize=8)
    fig.tight_layout(rect=(0, 0.075, 1, 1))
    fig.savefig(OUT / "figure1_copd_metabolites.png", dpi=300)
    plt.close(fig)

    significant = associations.loc[associations["q_bh_all"] < 0.05].sort_values("p")
    plotted = significant.loc[significant["metabolite"].eq("hippurate") & ~significant["taxon"].str.endswith(".nan")].head(8).iloc[::-1]
    fig, ax = plt.subplots(figsize=(7.2, 4.6))
    if len(plotted):
        labels = [row.taxon.rsplit(".", 1)[-1].replace("_", " ") for row in plotted.itertuples()]
        y_pos = np.arange(len(plotted))
        ax.errorbar(plotted["beta"], y_pos, xerr=[plotted["beta"] - plotted["lo"], plotted["hi"] - plotted["beta"]], fmt="o", capsize=3)
        ax.axvline(0, color="grey", lw=1)
        ax.set_yticks(y_pos, labels)
        ax.set_xlabel("Standardized plasma hippurate per 1 SD genus CLR (95% CI)")
    else:
        ax.text(0.5, 0.5, "No genus–metabolite associations passed BH FDR 0.05", ha="center", va="center", transform=ax.transAxes)
        ax.set_axis_off()
    ax.set_title("Arivale stool/plasma cohort: top 8 hippurate links")
    fig.tight_layout()
    fig.savefig(OUT / "figure2_gut_plasma.png", dpi=300)
    plt.close(fig)

    audit = {
        "design": "Cross-cohort; no person-level link between Arivale and SPIROMICS; Arivale models adjust eGFR",
        "st001639": {
            "matrix_samples": len(first_samples),
            "clinical_rows": len(sample_meta),
            "case": int((clinical["copd"] == 1).sum()),
            "control": int((clinical["copd"] == 0).sum()),
            "excluded_missing_copd": len(first_samples) - len(clinical),
            "total_features": features.shape[1],
            "all_named_estimable": int(estimable.sum()),
            "all_named_exclusion_counts": named.loc[~estimable, "status"].value_counts().to_dict(),
            "all_named_fdr_hits": int((named["q_bh_named"] < 0.05).sum()),
            "hippurate_q_bh_named": float(named.set_index("metabolite").loc["hippurate", "q_bh_named"]),
        },
        "arivale": {
            "gut_rows": len(gut),
            "plasma_rows": len(plasma),
            "matched_rows": len(shared),
            "genera_before_filter": len(taxon_columns),
            "genera_after_filter": len(taxa),
        },
        "candidate_metabolites": list(TARGETS),
        "source_sha256": {str(path.relative_to(ROOT)): sha256(path) for path in source_files},
    }
    (OUT / "audit.json").write_text(json.dumps(audit, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({"audit": audit, "copd_results": copd.to_dict("records"), "gut_fdr_hits": len(significant)}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
