"""Independent COPD stool cohort; no plasma metabolites were measured here.

Source: https://doi.org/10.34810/DATA2873 (CC0).
Run after analyze_pilot.py with the same bundled Python and .deps packages.
"""

from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / ".deps"))

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import statsmodels.api as sm
from statsmodels.stats.multitest import multipletests

SOURCE = ROOT / "sources"
OUT = ROOT / "results"


def fit_case_difference(y: pd.Series, clinical: pd.DataFrame) -> dict:
    design = clinical[["COPD", "Edad", "Sexo", "Tabaquismo"]].dropna().copy()
    design["Tabaquismo"] = design["Tabaquismo"].astype("category")
    design = pd.get_dummies(design, columns=["Tabaquismo"], drop_first=True, dtype=float)
    design["abundance"] = y.loc[design.index]
    design = design.replace([np.inf, -np.inf], np.nan).dropna()
    x = sm.add_constant(design.drop(columns="abundance"), has_constant="add").astype(float)
    fit = sm.OLS(design["abundance"].astype(float), x).fit(cov_type="HC3")
    interval = fit.conf_int().loc["COPD"]
    return {
        "n_complete": int(fit.nobs),
        "beta": float(fit.params["COPD"]),
        "lo": float(interval.iloc[0]),
        "hi": float(interval.iloc[1]),
        "p": float(fit.pvalues["COPD"]),
    }


def fit_fev1_within_copd(y: pd.Series, cases: pd.DataFrame) -> dict:
    data = cases[["FEV1", "Edad", "Sexo", "Tabaquismo"]].dropna().copy()
    data["Tabaquismo"] = data["Tabaquismo"].astype("category")
    data = pd.get_dummies(data, columns=["Tabaquismo"], drop_first=True, dtype=float)
    data["genus_z"] = y.loc[data.index]
    data = data.replace([np.inf, -np.inf], np.nan).dropna()
    x = sm.add_constant(data.drop(columns="FEV1"), has_constant="add").astype(float)
    fit = sm.OLS(data["FEV1"].astype(float), x).fit(cov_type="HC3")
    interval = fit.conf_int().loc["genus_z"]
    return {
        "n_complete": int(fit.nobs),
        "beta_fev1_pct_points_per_genus_sd": float(fit.params["genus_z"]),
        "lo": float(interval.iloc[0]),
        "hi": float(interval.iloc[1]),
        "p": float(fit.pvalues["genus_z"]),
    }


def main() -> None:
    paths = {
        "clinical": SOURCE / "dataverse2873-clinicalData.tab",
        "otu": SOURCE / "dataverse2873-stool_otu_count.tab",
        "taxonomy": SOURCE / "dataverse2873-stool_otu_taxonomy.tab",
        "readme": SOURCE / "dataverse2873-Readme.txt",
    }
    clinical = pd.read_csv(paths["clinical"], sep="\t", dtype={"ID": str}).set_index("ID")
    otu = pd.read_csv(paths["otu"], sep="\t").set_index("OTU")
    taxonomy = pd.read_csv(paths["taxonomy"], sep="\t").set_index("OTU")
    assert clinical.index.is_unique and otu.index.is_unique and taxonomy.index.is_unique
    assert len(clinical) == 90
    assert otu.index.equals(taxonomy.index) and otu.columns.is_unique
    assert set(otu.columns).issubset(clinical.index)
    assert set(clinical["COPD"].unique()) == {0, 1}
    assert (otu >= 0).all().all()

    shared = otu.columns.intersection(clinical.index)
    clinical = clinical.loc[shared].copy()
    OUT.mkdir(exist_ok=True)
    pd.DataFrame([{"segment": "DATA2873", "field": field, "denominator": len(clinical),
                   "missing": int(clinical[field].isna().sum())}
                  for field in ["COPD", "Edad", "Sexo", "Tabaquismo", "FEV1"]]).to_csv(
        OUT / "copd_stool_missingness.csv", index=False)
    baseline = []
    for status, group in clinical.groupby("COPD"):
        baseline.append({
            "copd": int(status), "n": len(group),
            "age_mean": float(group["Edad"].mean()),
            "age_sd": float(group["Edad"].std(ddof=1)),
            "male_n": int(group["Sexo"].eq(1).sum()),
            "former_smoker_n": int(group["Tabaquismo"].eq(0).sum()),
            "current_smoker_n": int(group["Tabaquismo"].eq(1).sum()),
            "never_smoker_n": int(group["Tabaquismo"].eq(2).sum()),
            "smoking_missing_n": int(group["Tabaquismo"].isna().sum()),
        })
    OUT.mkdir(exist_ok=True)
    pd.DataFrame(baseline).to_csv(OUT / "copd_stool_baseline.csv", index=False)
    counts = otu.loc[:, shared].T
    counts.columns = taxonomy.loc[counts.columns, "Genus"].astype(str)
    genus_counts = counts.T.groupby(level=0).sum().T
    rel = genus_counts.div(genus_counts.sum(axis=1), axis=0)
    keep = (rel.gt(0).mean() >= 0.20) & (rel.mean() >= 0.001)
    kept = keep[keep].index.tolist()
    assert len(kept) > 0
    clr = np.log(genus_counts + 0.5)
    clr = clr.sub(clr.mean(axis=1), axis=0)
    results = []
    for name in kept:
        value = clr[name]
        z = (value - value.mean()) / value.std(ddof=1)
        results.append({"genus": name, **fit_case_difference(z, clinical)})
    results = pd.DataFrame(results)
    results["q_bh_stool"] = multipletests(results["p"], method="fdr_bh")[1]
    OUT.mkdir(exist_ok=True)
    results.to_csv(OUT / "copd_stool_genus_adjusted.csv", index=False)

    cases = clinical.loc[clinical["COPD"].eq(1)].copy()
    assert len(cases) == 44 and cases["FEV1"].notna().sum() == 43
    case_rel = rel.loc[cases.index]
    case_keep = (case_rel.gt(0).mean() >= 0.20) & (case_rel.mean() >= 0.001)
    case_genera = case_keep[case_keep].index.tolist()
    fev1_rows = []
    for name in case_genera:
        value = clr.loc[cases.index, name]
        z = (value - value.mean()) / value.std(ddof=1)
        fev1_rows.append({"genus": name, **fit_fev1_within_copd(z, cases)})
    fev1 = pd.DataFrame(fev1_rows)
    assert np.isfinite(fev1[["beta_fev1_pct_points_per_genus_sd", "lo", "hi", "p"]].to_numpy()).all()
    fev1["q_bh_case_genera"] = multipletests(fev1["p"], method="fdr_bh")[1]
    fev1.to_csv(OUT / "copd_stool_fev1_within_cases.csv", index=False)

    arivale = pd.read_csv(OUT / "gut_plasma_adjusted.csv")
    hip = arivale.loc[arivale["metabolite"].eq("hippurate")].copy()
    hip["genus"] = hip["taxon"].str.rsplit(".", n=1).str[-1]
    hip = hip.loc[~hip["genus"].isin(["nan", "", "uncultured"])].copy()
    assert hip["genus"].is_unique
    overlap = results.merge(hip[["genus", "beta", "lo", "hi", "p", "q_bh_all"]], on="genus", suffixes=("_stool", "_arivale"))
    overlap["same_direction_as_hippurate_copd"] = np.sign(overlap["beta_stool"]) == np.sign(overlap["beta_arivale"])
    overlap.sort_values("p_stool").to_csv(OUT / "cross_cohort_genus_overlap.csv", index=False)

    ipa = arivale.loc[arivale["metabolite"].eq("indolepropionate")].copy()
    ipa["genus"] = ipa["taxon"].str.rsplit(".", n=1).str[-1]
    ipa = ipa.loc[~ipa["genus"].isin(["nan", "", "uncultured"])]
    assert ipa["genus"].is_unique
    fev1_overlap = fev1.merge(ipa[["genus", "beta", "q_bh_all"]], on="genus", suffixes=("_fev1", "_ipa"))
    fev1_overlap["same_direction_as_ipa_fev1"] = np.sign(fev1_overlap["beta_fev1_pct_points_per_genus_sd"]) == np.sign(fev1_overlap["beta"])
    fev1_overlap.sort_values("p").to_csv(OUT / "ipa_fev1_cross_cohort_overlap.csv", index=False)

    fig, ax = plt.subplots(figsize=(10.2, 4.9))
    focus = overlap.loc[overlap["q_bh_all"] < 0.05].sort_values("p_stool").head(10).iloc[::-1]
    if len(focus):
        y = np.arange(len(focus))
        ax.errorbar(
            focus["beta_stool"], y,
            xerr=[focus["beta_stool"] - focus["lo_stool"], focus["hi_stool"] - focus["beta_stool"]],
            fmt="o", capsize=3,
        )
        ax.axvline(0, color="grey", lw=1)
        ax.set_yticks(y, focus["genus"], fontsize=9)
        ax.set_xlabel("Adjusted genus CLR difference: COPD minus control (95% CI)", fontsize=10)
    else:
        ax.text(0.5, 0.5, "No exact genus overlap with Arivale hippurate hits", ha="center", va="center", transform=ax.transAxes)
        ax.set_axis_off()
    ax.set_title("Independent COPD stool cohort; no paired plasma data", fontsize=11)
    fig.tight_layout()
    fig.savefig(OUT / "figure3_copd_stool_overlap.png", dpi=300, bbox_inches="tight")
    plt.close(fig)

    focus_fev1 = fev1_overlap.loc[fev1_overlap["q_bh_all"] < 0.05].sort_values("p").head(10).iloc[::-1]
    fig, ax = plt.subplots(figsize=(9.4, 4.7))
    if len(focus_fev1):
        y = np.arange(len(focus_fev1))
        beta = focus_fev1["beta_fev1_pct_points_per_genus_sd"]
        ax.errorbar(beta, y, xerr=[beta - focus_fev1["lo"], focus_fev1["hi"] - beta], fmt="o", capsize=3)
        ax.axvline(0, color="grey", lw=1)
        ax.set_yticks(y, focus_fev1["genus"], fontsize=8)
        ax.set_xlabel("FEV1% predicted points per genus CLR SD (HC3 95% CI)")
    else:
        ax.text(0.5, 0.5, "No exact genus overlap with Arivale IPA hits", ha="center", va="center", transform=ax.transAxes)
        ax.set_axis_off()
    ax.set_title("Within 41 complete COPD cases; post hoc cross-cohort comparison", fontsize=10)
    fig.tight_layout()
    fig.savefig(OUT / "figure6_copd_stool_fev1.png", dpi=300, bbox_inches="tight")
    plt.close(fig)

    audit = {
        "dataset": "https://doi.org/10.34810/DATA2873",
        "source_sha256": {key: hashlib.sha256(path.read_bytes()).hexdigest() for key, path in paths.items()},
        "clinical_rows": 90,
        "stool_rows": len(shared),
        "stool_copd_cases": int(clinical["COPD"].sum()),
        "stool_controls": int((1 - clinical["COPD"]).sum()),
        "unique_genera": genus_counts.shape[1],
        "genera_after_filter": len(kept),
        "exact_genus_overlap": len(overlap),
        "hippurate_fdr_hit_overlap": int((overlap["q_bh_all"] < 0.05).sum()),
        "stool_fdr_hits": int((results["q_bh_stool"] < 0.05).sum()),
        "fev1_nonmissing_within_cases": int(cases["FEV1"].notna().sum()),
        "fev1_complete_case_n": int(fev1["n_complete"].min()),
        "fev1_genus_tests": len(fev1),
        "fev1_fdr_hits": int((fev1["q_bh_case_genera"] < 0.05).sum()),
        "ipa_exact_genus_overlap": len(fev1_overlap),
        "ipa_fdr_hit_overlap": int((fev1_overlap["q_bh_all"] < 0.05).sum()),
        "limitation": "Stool cohort lacks plasma metabolites; cross-cohort sign comparison is post hoc and not person-level linkage.",
    }
    (OUT / "copd_stool_audit.json").write_text(json.dumps(audit, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(audit, ensure_ascii=False, indent=2))
    print(overlap.sort_values("p_stool")[["genus", "beta_stool", "p_stool", "q_bh_stool", "beta_arivale", "q_bh_all", "same_direction_as_hippurate_copd"]].to_string(index=False))


if __name__ == "__main__":
    main()
