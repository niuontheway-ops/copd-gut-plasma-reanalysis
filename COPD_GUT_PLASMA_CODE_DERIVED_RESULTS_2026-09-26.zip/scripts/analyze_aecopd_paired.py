"""Audit and explore the published 22-person AECOPD paired-omics subset.

Source: Yang Y. Mendeley Data v1, doi:10.17632/vymjrkhr22.1.
The workbook supplies author-selected features, not the full omics matrices.
X-/F- are interpreted as serum/faeces from the Chinese sheet title and prefixes;
the file does not contain a separate machine-readable compartment dictionary.
"""

from __future__ import annotations

import hashlib
import io
import json
import sys
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / ".deps"))

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import openpyxl
import pandas as pd
from scipy.stats import spearmanr
from statsmodels.stats.multitest import multipletests

ARCHIVE = ROOT / "sources" / "mendeley-vymjrkhr22-data.zip"
OUT = ROOT / "results"
EXPECTED_SHA256 = "6117bf632f77382c8289415e7a5863d4125b48bdbe3f318c0b290fe13517561d"


def matrix(sheet: openpyxl.worksheet.worksheet.Worksheet) -> pd.DataFrame:
    rows = list(sheet.values)
    frame = pd.DataFrame(rows[1:], columns=rows[0]).set_index(rows[0][0])
    assert frame.index.is_unique and frame.columns.is_unique
    return frame


def main() -> None:
    digest = hashlib.sha256(ARCHIVE.read_bytes()).hexdigest()
    assert digest == EXPECTED_SHA256, "Source archive changed: inspect before reuse"
    with zipfile.ZipFile(ARCHIVE) as bundle:
        assert bundle.namelist() == ["data/data.xlsx"]
        workbook = openpyxl.load_workbook(io.BytesIO(bundle.read("data/data.xlsx")), read_only=True, data_only=True)
        assert workbook.sheetnames == ["人群", "空气污染物", "菌群α多样性", "菌群功能", "差异菌群", "血清和粪便差异代谢组"]
        clinical = matrix(workbook.worksheets[0])
        diversity = matrix(workbook.worksheets[2])
        taxa = matrix(workbook.worksheets[4]).T
        metabolites = matrix(workbook.worksheets[5]).T

    case_ids = clinical.index[clinical.index.str.startswith("AECOPD")]
    control_ids = clinical.index[clinical.index.str.match(r"^C\d+$")]
    assert len(clinical) == 42 and len(case_ids) == 22 and len(control_ids) == 20
    assert set(taxa.index) == set(clinical.index) and len(taxa.columns) == 35
    assert set(diversity.index) == set(case_ids)
    assert len(metabolites.columns) == 40 and len(metabolites.index) == 44
    x_ids = metabolites.index[metabolites.index.str.startswith("X-")]
    f_ids = metabolites.index[metabolites.index.str.startswith("F-")]
    assert set(x_ids.str.removeprefix("X-")) == set(case_ids)
    assert set(f_ids.str.removeprefix("F-")) == set(case_ids)

    taxa = taxa.apply(pd.to_numeric, errors="raise")
    serum = metabolites.loc[["X-" + i for i in case_ids]].set_axis(case_ids).apply(pd.to_numeric, errors="raise")
    fecal = metabolites.loc[["F-" + i for i in case_ids]].set_axis(case_ids).apply(pd.to_numeric, errors="raise")
    assert taxa.notna().all().all() and serum.notna().all().all() and fecal.notna().all().all()
    assert (taxa >= 0).all().all() and (serum > 0).all().all() and (fecal > 0).all().all()

    # The manuscript already tested associations with pollution. This is only
    # an exploratory audit of within-person cross-compartment correspondence.
    paired = []
    for compound in serum.columns:
        rho, p = spearmanr(serum[compound], fecal[compound])
        paired.append({"metabolite": compound, "n": 22, "spearman_rho": float(rho), "p": float(p)})
    paired = pd.DataFrame(paired)
    paired["q_BH_40"] = multipletests(paired["p"], method="fdr_bh")[1]

    # Author-selected differential taxa/metabolites make this a secondary,
    # hypothesis-generating screen, not a new unbiased biomarker discovery.
    associations = []
    for taxon in taxa.columns:
        abundance = taxa.loc[case_ids, taxon]
        for compound in serum.columns:
            rho, p = spearmanr(abundance, serum[compound])
            associations.append({"taxon": taxon, "serum_metabolite": compound, "n": 22,
                                 "spearman_rho": float(rho), "p": float(p),
                                 "taxon_nonzero_n": int((abundance > 0).sum())})
    associations = pd.DataFrame(associations)
    associations["q_BH_1400"] = multipletests(associations["p"], method="fdr_bh")[1]

    OUT.mkdir(exist_ok=True)
    paired.to_csv(OUT / "aecopd_serum_fecal_correlations.csv", index=False)
    associations.to_csv(OUT / "aecopd_taxon_serum_correlations.csv", index=False)
    audit = {
        "dataset_doi": "10.17632/vymjrkhr22.1",
        "archive_sha256": digest,
        "case_n": len(case_ids), "control_n": len(control_ids),
        "taxa_columns": len(taxa.columns), "metabolite_columns": len(serum.columns),
        "case_keys_exactly_match_all_omics": True,
        "metabolite_control_n": 0,
        "serum_fecal_tests": len(paired), "serum_fecal_q_lt_0_05": int((paired.q_BH_40 < 0.05).sum()),
        "taxon_serum_tests": len(associations), "taxon_serum_q_lt_0_05": int((associations.q_BH_1400 < 0.05).sum()),
        "compartment_prefix_interpretation": "X likely serum; F likely faeces; inferred from Chinese names, not an explicit data dictionary",
        "selection_limit": "Only 35 author-selected differential taxa and 40 author-selected differential metabolites; not full omics matrices",
    }
    (OUT / "aecopd_paired_audit.json").write_text(json.dumps(audit, indent=2, ensure_ascii=False), encoding="utf-8")

    from textwrap import fill

    plot = paired.nsmallest(10, "p").iloc[::-1]
    fig, ax = plt.subplots(figsize=(9, 6.2))
    ax.scatter(plot.spearman_rho, np.arange(len(plot)), color="#305f86", s=42)
    ax.axvline(0, color="black", linewidth=0.7)
    display_names = [fill(name.replace("(呼)", ""), width=34) for name in plot.metabolite]
    ax.set_yticks(np.arange(len(plot)), display_names, fontsize=8.5)
    ax.set_xlabel("Paired serum–faecal Spearman ρ (22 AECOPD patients)")
    ax.set_title("Ten lowest nominal P values; no FDR-significant pair")
    ax.set_xlim(-1, 1)
    for y, row in enumerate(plot.itertuples()):
        ax.text(1.02, y, f"q={row.q_BH_40:.3f}", va="center", fontsize=8,
                transform=ax.get_yaxis_transform())
    fig.subplots_adjust(left=0.43, right=0.84, top=0.88, bottom=0.12)
    fig.savefig(OUT / "figure5_aecopd_paired_metabolites.png", dpi=300)
    plt.close(fig)
    print(json.dumps(audit, ensure_ascii=False))


if __name__ == "__main__":
    main()
