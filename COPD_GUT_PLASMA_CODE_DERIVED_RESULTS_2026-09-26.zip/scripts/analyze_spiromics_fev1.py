"""Age-adjusted SPIROMICS plasma metabolite / FEV1 sensitivity analysis.

ST002088 and ST001639 originate from SPIROMICS; this is not an independent
external cohort. Sample IDs are not linked across studies here.
"""

from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / ".deps"))

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import statsmodels.api as sm
from statsmodels.stats.multitest import multipletests

from analyze_pilot import TARGETS, read_workbench_matrix, zlog

SOURCE = ROOT / "sources"
OUT = ROOT / "results"


def main() -> None:
    paths = [SOURCE / f"ST002088-AN00340{i}.txt" for i in range(6, 10)]
    meta_path = SOURCE / "ST002088-samples.html"
    matrices = [read_workbench_matrix(path) for path in paths]
    samples = list(matrices[0][0].index)
    for matrix, factors in matrices[1:]:
        assert set(matrix.index) == set(samples)
        assert factors.sort_index().equals(matrices[0][1].sort_index())
    metabolites = pd.concat([matrix.reindex(samples) for matrix, _ in matrices], axis=1)
    assert metabolites.columns.is_unique and set(TARGETS).issubset(metabolites.columns)
    clinical = next(table for table in pd.read_html(meta_path) if "Sample name" in table.columns).set_index("Sample name")
    assert clinical.index.is_unique and set(samples) == set(clinical.index)
    clinical = clinical.loc[samples]
    columns = {
        "Sample_Data:POST_FEV1_DERV_V1": "fev1_l",
        "AGE_DERV_V1": "age",
        "BMI_CM_V1": "bmi",
        "SMOKING_PACK_YEARS_V1": "pack_years",
        "GENDER": "sex",
        "RACE.ETH": "race",
        "smokStatus": "smoking",
        "SITE_cat": "site",
    }
    clinical = clinical[list(columns)].rename(columns=columns)
    never_dash = clinical["smoking"].eq("Never Smoked") & clinical["pack_years"].eq("-")
    assert int(never_dash.sum()) == 55
    clinical.loc[never_dash, "pack_years"] = "0"
    for column in ["fev1_l", "age", "bmi", "pack_years"]:
        clinical[column] = pd.to_numeric(clinical[column], errors="coerce")
    clinical["pack_years"] = clinical["pack_years"].where(clinical["pack_years"] >= 0)
    fev1_missing = [{"segment": "ST002088", "field": field, "denominator": len(clinical),
                     "missing_or_nonpositive": int(clinical[field].isna().sum())}
                    for field in ["fev1_l", "age", "bmi", "pack_years", "sex", "race", "smoking", "site"]]
    for name in TARGETS:
        values = pd.to_numeric(metabolites[name], errors="coerce")
        fev1_missing.append({"segment": "ST002088", "field": name, "denominator": len(clinical),
                             "missing_or_nonpositive": int((~(values > 0)).sum())})
    pd.DataFrame(fev1_missing).to_csv(OUT / "st002088_missingness.csv", index=False)
    pd.DataFrame([{
        "n": len(clinical), "age_mean": float(clinical["age"].mean()),
        "bmi_mean": float(clinical["bmi"].mean()),
        "fev1_l_mean": float(clinical["fev1_l"].mean()),
        "female_n": int(clinical["sex"].eq("Female").sum()),
        "current_smoker_n": int(clinical["smoking"].eq("Current Smoker").sum()),
        "former_smoker_n": int(clinical["smoking"].eq("Former Smoker").sum()),
        "never_smoker_n": int(clinical["smoking"].eq("Never Smoked").sum()),
    }]).to_csv(OUT / "st002088_baseline.csv", index=False)
    results = []
    for name in TARGETS:
        frame = clinical.copy()
        frame["metabolite_z"] = zlog(metabolites[name])
        frame = frame.replace([np.inf, -np.inf], np.nan).dropna()
        x = pd.get_dummies(
            frame[["metabolite_z", "age", "bmi", "pack_years", "sex", "race", "smoking", "site"]],
            columns=["sex", "race", "smoking", "site"], drop_first=True, dtype=float,
        )
        fit = sm.OLS(frame["fev1_l"], sm.add_constant(x, has_constant="add")).fit(cov_type="HC3")
        lo, hi = fit.conf_int().loc["metabolite_z"]
        results.append({
            "metabolite": name, "n_complete": int(fit.nobs),
            "beta_l_per_sd": float(fit.params["metabolite_z"]),
            "lo": float(lo), "hi": float(hi), "p": float(fit.pvalues["metabolite_z"]),
        })
    results = pd.DataFrame(results)
    results["q_bh_5"] = multipletests(results["p"], method="fdr_bh")[1]
    results.to_csv(OUT / "spiromics_fev1_metabolites_adjusted.csv", index=False)

    fig, ax = plt.subplots(figsize=(7.5, 3.4))
    y = np.arange(len(results))
    ax.errorbar(
        results["beta_l_per_sd"], y,
        xerr=[results["beta_l_per_sd"] - results["lo"], results["hi"] - results["beta_l_per_sd"]],
        fmt="o", capsize=3,
    )
    ax.axvline(0, color="grey", lw=1)
    ax.set_yticks(y, results["metabolite"])
    ax.invert_yaxis()
    ax.set_xlabel("Adjusted post-bronchodilator FEV1 (L) per 1 SD metabolite (95% CI)")
    ax.set_title("SPIROMICS ST002088: sensitivity analysis, no height covariate")
    fig.tight_layout()
    fig.savefig(OUT / "figure4_spiromics_fev1.png", dpi=300)
    plt.close(fig)

    audit = {
        "study": "https://www.metabolomicsworkbench.org/data/DRCCMetadata.php?StudyID=ST002088",
        "metabolite_samples": len(samples),
        "clinical_samples": len(clinical),
        "never_smoker_dash_pack_years_set_to_zero": int(never_dash.sum()),
        "source_sha256": {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in [*paths, meta_path]},
        "limitations": [
            "Potential overlap with ST001639 SPIROMICS participants; not independent replication.",
            "FEV1 is liters, not percent predicted; height and COPD case labels are absent.",
            "Cross-study sample IDs are not linked or inferred.",
        ],
    }
    (OUT / "spiromics_fev1_audit.json").write_text(json.dumps(audit, indent=2), encoding="utf-8")
    print(json.dumps(audit, indent=2))
    print(results.to_string(index=False))


if __name__ == "__main__":
    main()
