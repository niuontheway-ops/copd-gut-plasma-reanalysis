"""Validate Xu et al. 2022 source tables and stress-test the XuQ gut–blood edge.

The original publication calls the specimen plasma; HuMMANet labels it serum.
This is a family cohort without a verified COPD phenotype.
"""

import hashlib
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / ".deps"))

import numpy as np
import openpyxl
import pandas as pd
import rdata
import statsmodels.api as sm
from statsmodels.stats.multitest import multipletests

RDS = ROOT / "sources/hummanet/xuq_serum_2022.rds"
XLSX = ROOT / "sources/hummanet/xu2022_supplementary_tables.xlsx"
OUT = ROOT / "results"
NAMES = ("indolepropionate", "indoleacetate", "indolelactate", "p-cresol sulfate", "hippurate")
RDS_MD5 = "6967ac00aa162578614a9ea3219ce724"
XLSX_SHA256 = "a40ddec2959a46a1923ac1a9b1f29c768aede69e9d8ca309c2c7be8c6934eddf"


def fit_pair(y_signal, x_clr, covariates, family, robust, min_n=70):
    joined = pd.concat([y_signal.rename("signal"), x_clr.rename("genus"), covariates], axis=1).dropna()
    assert len(joined) >= min_n
    y = np.log2(joined.pop("signal"))
    y = (y - y.mean()) / y.std(ddof=1)
    joined["genus"] = (joined["genus"] - joined["genus"].mean()) / joined["genus"].std(ddof=1)
    x = sm.add_constant(joined, has_constant="add")
    kwargs = {"cov_type": "cluster", "cov_kwds": {"groups": family.loc[x.index]}} if robust else {"cov_type": "HC3"}
    fit = sm.OLS(y, x).fit(**kwargs)
    lo, hi = fit.conf_int().loc["genus"]
    return {"n": len(x), "family_stems": family.loc[x.index].nunique(), "beta": float(fit.params["genus"]),
            "ci95_low": float(lo), "ci95_high": float(hi), "p": float(fit.pvalues["genus"])}


def main():
    assert hashlib.md5(RDS.read_bytes()).hexdigest() == RDS_MD5
    assert hashlib.sha256(XLSX.read_bytes()).hexdigest() == XLSX_SHA256
    data = rdata.read_rds(RDS, default_encoding="utf-8")
    metadata = data["MetadataProfile"].set_index("sample_id")
    species = data["taxaAbundanceProfile"].set_index("sample_id").astype(float)
    blood = data["OriginalMetaboliteProfile"].set_index("sample_id")
    assert metadata.index.equals(species.index) and metadata.index.equals(blood.index)
    ids = metadata.index.to_series().astype(str).str.removesuffix("s")
    assert ids.is_unique and ids.str.match(r"^QCS-\d{3}-[123]$").all()

    source = pd.read_excel(XLSX, sheet_name="Table S1 Metadata", header=1)
    assert len(source) == source.iloc[:, 0].nunique() == 348
    source_ids = source.iloc[:, 0].astype(str)
    source_stems = source_ids.str.rsplit("-", n=1).str[0]
    source_parent_stems = set(source_stems[source_ids.str.endswith("-1")])
    assert len(source_parent_stems) == 116 and source_stems.nunique() == 123
    source = source.set_index(source.columns[0]).reindex(ids)
    source.index = metadata.index
    assert source.notna().any(axis=1).all()
    assert np.allclose(pd.to_numeric(source.iloc[:, 22], errors="coerce"),
                       pd.to_numeric(metadata.Age, errors="coerce"), equal_nan=True)
    assert source.iloc[:, 23].isin([1, 2]).all()
    control = metadata.diseaseCat.eq("Control")
    no_recorded_disease = source.iloc[:, :12].eq("N").all(axis=1)
    assert int(control.sum()) == 124
    assert int((control & no_recorded_disease).sum()) == 120

    book = openpyxl.load_workbook(XLSX, read_only=True, data_only=True)
    raw_rows = list(book["Table S11 Raw data plasma metab"].values)
    tube_to_col = {str(label): i for i, label in enumerate(raw_rows[4]) if str(label).startswith("QCS-")}
    assert len(tube_to_col) == 382 and all(label in tube_to_col for label in ids)
    raw = {}
    raw_hmdb = {}
    for name in NAMES:
        matches = [row for row in raw_rows[6:] if str(row[1]).lower() == name]
        assert len(matches) == 1
        row = matches[0]
        raw[name] = pd.Series([pd.to_numeric(row[tube_to_col[label]], errors="coerce") for label in ids], index=metadata.index)
        raw_hmdb[name] = str(row[12])
        deposited = pd.to_numeric(blood[name], errors="coerce")
        assert np.allclose(raw[name], deposited, rtol=1e-5, atol=0.1, equal_nan=True)
    assert raw_hmdb["hippurate"] == "HMDB00714"
    assert raw_hmdb["indolepropionate"] == "HMDB02302"

    genera = species.T.groupby([str(c).split("_", 1)[0] for c in species.columns]).sum().T
    assert np.allclose(genera.sum(axis=1), 1.0)
    kept = genera.columns[(genera.gt(0).mean() >= 0.20) & (genera.mean() >= 0.001)]
    clr = np.log(genera[kept] + 1e-6)
    clr = clr.sub(clr.mean(axis=1), axis=0)
    arivale = pd.read_csv(OUT / "gut_plasma_adjusted.csv")
    arivale = arivale[arivale.metabolite.isin(NAMES)].copy()
    arivale["genus"] = arivale.taxon.str.rsplit(".", n=1).str[-1]
    arivale = arivale[arivale.genus.isin(kept)]
    assert len(arivale) == 115 and not arivale.duplicated(["metabolite", "genus"]).any()

    age = pd.to_numeric(source.iloc[:, 22], errors="coerce")
    sex_male = source.iloc[:, 23].eq(1).astype(float).rename("male")
    bmi = pd.to_numeric(source.iloc[:, 26], errors="coerce").rename("bmi")
    creatinine = pd.to_numeric(source.iloc[:, 43], errors="coerce")
    assert creatinine.gt(0).sum() >= 300
    log_creatinine = np.log2(creatinine).rename("log2_creatinine")
    cystatin = pd.to_numeric(source.iloc[:, 47], errors="coerce")
    assert cystatin.gt(0).sum() >= 300
    log_cystatin = np.log2(cystatin).rename("log2_cystatin_c")
    smoker = source.iloc[:, 85].map({"Y": 1.0, "N": 0.0}).rename("current_smoker")
    fruit = pd.to_numeric(source.iloc[:, 70], errors="coerce").rename("fruit_frequency_code")
    recent_antibiotic_none = source.iloc[:, 21].eq("N")
    family = ids.str.rsplit("-", n=1).str[0]
    family.index = metadata.index

    # The original paper identifies -1 as the older parent and -2/-3 as offspring.
    # Complete-disease-record, recent-antibiotic-free restriction and family-clustered
    # SE are sensitivity analyses, not a pre-registered confirmatory validation.
    eligible = control & no_recorded_disease & recent_antibiotic_none
    covariates = pd.concat([age.rename("age"), sex_male, bmi, log_creatinine, smoker, fruit], axis=1)
    rows = []
    for pair in arivale.itertuples(index=False):
        selected_y = raw[pair.metabolite].where(eligible & raw[pair.metabolite].gt(0))
        selected_x = clr[pair.genus].where(eligible)
        result = fit_pair(selected_y, selected_x, covariates, family, robust=True)
        rows.append({"metabolite": pair.metabolite, "genus": pair.genus, **result})
    results = pd.DataFrame(rows)
    results["q_bh_115"] = multipletests(results.p, method="fdr_bh")[1]
    assert results[["beta", "ci95_low", "ci95_high", "p", "q_bh_115"]].notna().all().all()
    results.to_csv(OUT / "xuq_original_source_robustness.csv", index=False)

    key = results[(results.metabolite == "hippurate") & (results.genus == "Bacteroides")].iloc[0].to_dict()
    key_y = raw["hippurate"].where(eligible & raw["hippurate"].gt(0))
    key_x = clr["Bacteroides"].where(eligible)
    alt_covariates = covariates.drop(columns="log2_creatinine").join(log_cystatin)
    alt = fit_pair(key_y, key_x, alt_covariates, family, robust=True)
    strata = {}
    for label, part in (("older_parent", ids.str.endswith("-1")), ("offspring", ids.str.endswith(("-2", "-3")))):
        mask = eligible & part.set_axis(metadata.index)
        # Age, sex, renal function only: the older-parent stratum is small.
        strata[label] = fit_pair(raw["hippurate"].where(mask & raw["hippurate"].gt(0)),
                                 clr["Bacteroides"].where(mask),
                                 covariates[["age", "male", "log2_creatinine"]], family, robust=True, min_n=25)
    audit = {
        "original_source": "Xu et al., Nature Aging 2022, DOI 10.1038/s43587-022-00193-0, Supplementary Tables S1 and S11",
        "original_source_sha256": XLSX_SHA256,
        "harmonized_bundle_md5": RDS_MD5,
        "source_metadata_rows": 348,
        "source_metadata_distinct_id_stems": source_stems.nunique(),
        "source_metadata_parent_suffix_1_stems": len(source_parent_stems),
        "source_metadata_stems_without_parent_suffix_1": source_stems.nunique() - len(source_parent_stems),
        "source_plasma_tube_labels": len(tube_to_col),
        "bundle_matched_source_metadata_and_plasma": 305,
        "source_family_id_stems_in_bundle": family.nunique(),
        "source_family_id_stems_control": family[control].nunique(),
        "control_labels": int(control.sum()),
        "control_labels_with_all_12_disease_flags_N": int((control & no_recorded_disease).sum()),
        "eligible_control_no_recorded_disease_no_recent_antibiotic": int(eligible.sum()),
        "source_covariate_nonmissing_in_control": {
            "sex": int(source.iloc[control.to_numpy(), 23].notna().sum()),
            "bmi": int(bmi[control].notna().sum()),
            "creatinine": int(creatinine[control].notna().sum()),
            "cystatin_c": int(cystatin[control].notna().sum()),
            "current_smoking": int(smoker[control].notna().sum()),
            "fruit_frequency": int(fruit[control].notna().sum()),
        },
        "original_raw_hmdb": raw_hmdb,
        "primary_source_specimen_conflict": "Xu et al. Table S11 and article explicitly say plasma; HuMMANet bundle labels Metabolomics_body_site Serum. Treat as plasma from original source, not independent serum assay.",
        "source_adjusted_115_tests_q_below_0_05": int((results.q_bh_115 < 0.05).sum()),
        "bacteroides_hippurate_source_adjusted": key,
        "bacteroides_hippurate_cystatin_c_instead_of_creatinine": alt,
        "bacteroides_hippurate_generation_strata": strata,
        "limits": "Post hoc observational association; family-stem cluster IDs inferred from source codebook; source data lacks verified COPD and comprehensive dietary/medication adjustment.",
    }
    (OUT / "xuq_original_source_audit.json").write_text(json.dumps(audit, indent=2), encoding="utf-8")
    print(json.dumps(audit, indent=2))


if __name__ == "__main__":
    main()
