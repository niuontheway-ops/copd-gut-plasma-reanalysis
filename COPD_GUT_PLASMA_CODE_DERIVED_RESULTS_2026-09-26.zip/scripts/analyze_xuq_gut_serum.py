"""Test transport of five gut-blood associations to HuMMANet XuQ_Serum_2022.

The harmonized bundle says serum; Xu et al. 2022 source Table S11 says plasma.
This is not a COPD cohort or causal test.
"""

import hashlib
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / ".deps"))

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import rdata
import statsmodels.api as sm
from scipy.stats import spearmanr
from statsmodels.stats.multitest import multipletests

SOURCE = ROOT / "sources" / "hummanet" / "xuq_serum_2022.rds"
ARIVALE = ROOT / "results" / "gut_plasma_adjusted.csv"
OUT = ROOT / "results"
CANDIDATES = ("indolepropionate", "indoleacetate", "indolelactate", "p-cresol sulfate", "hippurate")
EXPECTED_MD5 = "6967ac00aa162578614a9ea3219ce724"


def main():
    assert hashlib.md5(SOURCE.read_bytes()).hexdigest() == EXPECTED_MD5
    bundle = rdata.read_rds(SOURCE, default_encoding="utf-8")
    metadata = bundle["MetadataProfile"].set_index("sample_id")
    species = bundle["taxaAbundanceProfile"].set_index("sample_id").astype(float)
    serum = bundle["OriginalMetaboliteProfile"].set_index("sample_id")
    assert len(metadata) == len(species) == len(serum) == 305
    assert metadata.index.is_unique and species.index.is_unique and serum.index.is_unique
    assert metadata.index.equals(species.index) and metadata.index.equals(serum.index)
    assert metadata["Subject_ID"].notna().all() and metadata["Subject_ID"].is_unique
    assert metadata["longitudinal"].eq("No").all()
    assert metadata["body_site"].eq("Fecal").all()
    assert metadata["Metabolomics_body_site"].eq("Serum").all()
    assert np.allclose(species.sum(axis=1), 1.0)
    assert all(name in serum for name in CANDIDATES)
    assert metadata["Gender"].isna().all() and metadata["BMI"].isna().all()
    identifiers = bundle["metaboliteIdentifierMapping"].set_index("Query_Name")
    assert identifiers.index.is_unique and all(name in identifiers.index for name in CANDIDATES)
    assert identifiers.loc["hippurate", "HMDB_ID"] == "HMDB0000714"
    assert identifiers.loc["indolepropionate", "HMDB_ID"] == "HMDB0002302"

    # Species names have a genus prefix; retain only exact Arivale genus names.
    genera = species.T.groupby([str(c).split("_", 1)[0] for c in species.columns]).sum().T
    assert np.allclose(genera.sum(axis=1), 1.0)
    kept = genera.columns[(genera.gt(0).mean() >= 0.20) & (genera.mean() >= 0.001)]
    assert "Bacteroides" in kept
    clr = np.log(genera[kept] + 1e-6)
    clr = clr.sub(clr.mean(axis=1), axis=0)
    previous = pd.read_csv(ARIVALE)
    previous = previous[previous.metabolite.isin(CANDIDATES)].copy()
    previous["genus"] = previous.taxon.str.rsplit(".", n=1).str[-1]
    previous = previous[previous.genus.isin(kept)]
    assert not previous.duplicated(["metabolite", "genus"]).any()
    assert previous.metabolite.nunique() == 5

    age = pd.to_numeric(metadata["Age"], errors="coerce")
    controls = metadata["diseaseCat"].eq("Control")
    rows = []
    for population, population_mask in (("control_label_only", controls), ("all_participants", pd.Series(True, index=controls.index))):
        for source in previous.itertuples(index=False):
            signal = pd.to_numeric(serum[source.metabolite], errors="coerce")
            valid = population_mask & age.notna() & signal.gt(0)
            assert valid.sum() >= 100
            y = np.log2(signal[valid])
            y = (y - y.mean()) / y.std(ddof=1)
            x = clr.loc[valid, source.genus]
            x = (x - x.mean()) / x.std(ddof=1)
            design = pd.DataFrame({"const": 1.0, "genus": x, "age": age[valid]}, index=x.index)
            if population == "all_participants":
                design["noncontrol"] = (~controls[valid]).astype(float)
            fit = sm.OLS(y, design).fit(cov_type="HC3")
            lo, hi = fit.conf_int().loc["genus"]
            rows.append({
                "population": population, "metabolite": source.metabolite, "genus": source.genus,
                "n": int(valid.sum()), "xuq_beta": float(fit.params["genus"]),
                "xuq_ci95_low": float(lo), "xuq_ci95_high": float(hi), "xuq_p": float(fit.pvalues["genus"]),
                "arivale_beta": float(source.beta), "arivale_q_355": float(source.q_bh_all),
            })
    result = pd.DataFrame(rows)
    result["xuq_q_family"] = np.nan
    for population in result.population.unique():
        mask = result.population.eq(population)
        result.loc[mask, "xuq_q_family"] = multipletests(result.loc[mask, "xuq_p"], method="fdr_bh")[1]
    result["same_sign"] = np.sign(result.xuq_beta) == np.sign(result.arivale_beta)
    result.to_csv(OUT / "hummanet_xuq_gut_serum_transport.csv", index=False)
    primary = result[result.population.eq("control_label_only")]
    hits = primary[primary.arivale_q_355 < 0.05]
    hippurate = pd.to_numeric(serum["hippurate"], errors="coerce")
    rank_check = {}
    for label, eligible in (("control_label_only", controls), ("all_participants", pd.Series(True, index=controls.index))):
        valid = eligible & age.notna() & hippurate.gt(0)
        rho, p = spearmanr(genera.loc[valid, "Bacteroides"], hippurate[valid])
        rank_check[label] = {"n": int(valid.sum()), "rho": float(rho), "p_unadjusted": float(p)}
    audit = {
        "dataset": "HuMMANet v3 XuQ_Serum_2022",
        "source_md5": EXPECTED_MD5,
        "paired_sample_ids": 305,
        "control_label_n": int(controls.sum()),
        "unique_subject_ids": int(metadata.Subject_ID.nunique()),
        "age_nonmissing": int(age.notna().sum()),
        "gender_nonmissing": int(metadata.Gender.notna().sum()),
        "bmi_nonmissing": int(metadata.BMI.notna().sum()),
        "species_features": species.shape[1],
        "candidate_identifiers": {
            name: {field: str(identifiers.loc[name, field]) for field in ("HMDB_ID", "ChEBI_ID", "Standardized_Name")}
            for name in CANDIDATES
        },
        "genus_groups_all": genera.shape[1],
        "genus_groups_filtered": len(kept),
        "exact_arivale_genus_overlap": previous.genus.nunique(),
        "tests_per_population": len(previous),
        "control_label_primary_q_below_0_05": int((primary.xuq_q_family < 0.05).sum()),
        "all_participants_q_below_0_05": int(((result.population == "all_participants") & (result.xuq_q_family < 0.05)).sum()),
        "arivale_hits_tested": len(hits),
        "arivale_hits_same_sign": int(hits.same_sign.sum()),
        "arivale_hits_xuq_q_below_0_05_same_sign": int((hits.same_sign & (hits.xuq_q_family < 0.05)).sum()),
        "unadjusted_raw_bacteroides_hippurate_spearman": rank_check,
        "limits": "This harmonized bundle omits renal function, diet, medications, sex and BMI, but Xu et al. 2022 Supplementary Table S1 supplies some of these fields; see audit_xuq_original_source.py. Original paper/Table S11 call the matching blood specimen plasma, although this bundle says serum. Species-prefix genus grouping and CLR pseudocount are exploratory. Respiratory label is not verified COPD.",
    }
    (OUT / "hummanet_xuq_gut_serum_audit.json").write_text(json.dumps(audit, indent=2), encoding="utf-8")

    fig, ax = plt.subplots(figsize=(7.2, 5.2))
    for name in CANDIDATES:
        part = primary[primary.metabolite.eq(name)]
        ax.scatter(part.arivale_beta, part.xuq_beta, s=24, alpha=0.75, label=name)
    ax.axhline(0, color="0.6", lw=1)
    ax.axvline(0, color="0.6", lw=1)
    ax.set(xlabel="Arivale genus-metabolite beta (456 paired people)",
           ylabel="XuQ Control-labelled plasma beta (age-adjusted)",
           title="Exact-name genera: exploratory transport check")
    ax.legend(fontsize=8, loc="upper left", bbox_to_anchor=(1.02, 1), borderaxespad=0)
    fig.tight_layout()
    fig.savefig(OUT / "figure8_xuq_gut_serum_transport.png", dpi=300)
    plt.close(fig)
    print(json.dumps(audit, indent=2))
    print(primary[primary.genus.eq("Bacteroides")].to_string(index=False))


if __name__ == "__main__":
    main()
