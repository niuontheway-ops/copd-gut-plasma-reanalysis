"""Audit Bowerman 2020 stool 16S data and compare COPD genus directions with DATA2873.

Both analyses below are unadjusted because the Bowerman public supplement does
not provide individual age/sex for all 57 participants. This is not a blood
metabolite analysis or a clinical validation model.
"""

from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / ".deps"))

import numpy as np
import pandas as pd
import statsmodels.api as sm
import matplotlib.pyplot as plt
from statsmodels.stats.multitest import multipletests

SOURCE = ROOT / "sources"
OUT = ROOT / "results"
BOWERMAN_URL = (
    "https://static-content.springer.com/esm/art%3A10.1038%2Fs41467-020-19701-0/"
    "MediaObjects/41467_2020_19701_MOESM6_ESM.xlsx"
)
SUPPLEMENT_URL = BOWERMAN_URL.replace("MOESM6", "MOESM5")


def fit_genus(counts: pd.DataFrame, total: pd.Series, status: pd.Series, cohort: str) -> pd.DataFrame:
    """Same unadjusted log-relative-abundance model in each independent cohort."""
    assert counts.index.equals(total.index) and counts.index.equals(status.index)
    assert total.gt(0).all() and status.isin([0, 1]).all()
    rel = counts.div(total, axis=0)
    keep = (rel.gt(0).mean() >= 0.20) & (rel.mean() >= 0.001)
    rows = []
    for genus in keep[keep].index:
        y = np.log2((counts[genus] + 0.5) / total)
        y = (y - y.mean()) / y.std(ddof=1)
        assert np.isfinite(y).all()
        x = sm.add_constant(status.rename("COPD").astype(float), has_constant="add")
        fit = sm.OLS(y, x).fit(cov_type="HC3")
        ci = fit.conf_int().loc["COPD"]
        rows.append({
            "cohort": cohort, "genus": genus, "n": int(fit.nobs),
            "copd_n": int(status.sum()), "control_n": int((1 - status).sum()),
            "prevalence": float(rel[genus].gt(0).mean()),
            "mean_relative_abundance": float(rel[genus].mean()),
            "beta_copd_minus_control_sd": float(fit.params["COPD"]),
            "ci_low": float(ci.iloc[0]), "ci_high": float(ci.iloc[1]),
            "p": float(fit.pvalues["COPD"]),
        })
    result = pd.DataFrame(rows).sort_values("genus").reset_index(drop=True)
    assert len(result) and np.isfinite(result["p"]).all()
    result["q_bh_within_cohort"] = multipletests(result["p"], method="fdr_bh")[1]
    return result


def main() -> None:
    source_path = SOURCE / "bowerman2020_source_data.xlsx"
    supplement_path = SOURCE / "bowerman2020_supplementary_data.xlsx"
    source = pd.read_excel(source_path, sheet_name="16S_raw_SV_counts")
    sample_key = pd.read_excel(supplement_path, sheet_name="Supp. Data 28", header=2)
    participant = pd.read_excel(supplement_path, sheet_name="Supp. Data 2", header=2)
    sample_key = sample_key[["Sample", "ID", "Final read count"]]
    participant = participant[["ID", "Type"]]
    assert source["otu"].is_unique
    assert sample_key["Sample"].is_unique and sample_key["ID"].is_unique
    assert participant["ID"].is_unique
    assert len(sample_key) == len(participant) == 57
    assert set(sample_key["ID"]) == set(participant["ID"])
    assert set(sample_key["Sample"]).issubset(source.columns)
    key = sample_key.merge(participant, on="ID", validate="one_to_one")
    assert key["Type"].value_counts().to_dict() == {"Healthy": 29, "COPD": 28}
    samples = key["Sample"].tolist()
    raw = source.set_index("otu")[samples].T
    assert raw.index.is_unique and raw.columns.is_unique
    assert raw.notna().all().all() and raw.ge(0).all().all()
    assert np.all(np.mod(raw.to_numpy(), 1) == 0)
    assert raw.sum(axis=1).gt(0).all()
    taxon = source.set_index("otu")["Taxon"]
    genus = taxon.str.extract(r"D_5__([^;]+)", expand=False)
    # Only unequivocal one-word genus labels are comparable across 16S taxonomies.
    genus = genus.where(genus.str.fullmatch(r"[A-Z][A-Za-z]+", na=False))
    named = raw.T.loc[genus.notna()].copy()
    named["genus"] = genus.loc[genus.notna()].to_numpy()
    bow_counts = named.groupby("genus").sum().T
    bow_status = key.set_index("Sample").loc[raw.index, "Type"].eq("COPD").astype(int)
    bow = fit_genus(bow_counts, raw.sum(axis=1), bow_status, "Bowerman2020")

    otu = pd.read_csv(SOURCE / "dataverse2873-stool_otu_count.tab", sep="\t").set_index("OTU")
    taxonomy = pd.read_csv(SOURCE / "dataverse2873-stool_otu_taxonomy.tab", sep="\t").set_index("OTU")
    clinical = pd.read_csv(SOURCE / "dataverse2873-clinicalData.tab", sep="\t", dtype={"ID": str}).set_index("ID")
    assert otu.index.equals(taxonomy.index) and otu.columns.is_unique
    assert set(otu.columns).issubset(clinical.index)
    d_raw = otu.T
    assert d_raw.notna().all().all() and d_raw.ge(0).all().all()
    d_genus = taxonomy["Genus"].astype(str)
    d_genus = d_genus.where(d_genus.str.fullmatch(r"[A-Z][A-Za-z]+", na=False))
    d_named = d_raw.T.loc[d_genus.notna()].copy()
    d_named["genus"] = d_genus.loc[d_genus.notna()].to_numpy()
    d_counts = d_named.groupby("genus").sum().T
    d_status = clinical.loc[d_raw.index, "COPD"].astype(int)
    assert len(d_status) == 65 and int(d_status.sum()) == 44
    data2873 = fit_genus(d_counts, d_raw.sum(axis=1), d_status, "DATA2873")

    combined = pd.concat([bow, data2873], ignore_index=True)
    overlap = bow.merge(data2873, on="genus", suffixes=("_bowerman", "_data2873"))
    overlap["same_direction"] = (
        np.sign(overlap["beta_copd_minus_control_sd_bowerman"])
        == np.sign(overlap["beta_copd_minus_control_sd_data2873"])
    )
    overlap = overlap.sort_values("p_bowerman").reset_index(drop=True)
    count_match = (source[samples].gt(0).sum(axis=1) == source["Count of samples present"]).sum()
    source_totals = raw.sum(axis=1)
    final_reads = key.set_index("Sample").loc[raw.index, "Final read count"]
    audit = {
        "article_doi": "https://doi.org/10.1038/s41467-020-19701-0",
        "source_url": BOWERMAN_URL,
        "supplement_url": SUPPLEMENT_URL,
        "source_sha256": hashlib.sha256(source_path.read_bytes()).hexdigest(),
        "supplement_sha256": hashlib.sha256(supplement_path.read_bytes()).hexdigest(),
        "source_variant_rows": int(len(source)),
        "source_sample_columns": int(len(samples)),
        "phenotype_key_sample_id_unique": bool(key["Sample"].is_unique),
        "phenotype_key_participant_id_unique": bool(key["ID"].is_unique),
        "bowerman_copd_n": int(bow_status.sum()),
        "bowerman_control_n": int((1 - bow_status).sum()),
        "bowerman_one_word_named_genera": int(bow_counts.shape[1]),
        "bowerman_genera_tested": int(len(bow)),
        "bowerman_fdr_hits": int(bow["q_bh_within_cohort"].lt(0.05).sum()),
        "data2873_copd_n": int(d_status.sum()),
        "data2873_control_n": int((1 - d_status).sum()),
        "data2873_genera_tested": int(len(data2873)),
        "data2873_fdr_hits": int(data2873["q_bh_within_cohort"].lt(0.05).sum()),
        "filtered_exact_name_overlap": int(len(overlap)),
        "same_direction_overlap": int(overlap["same_direction"].sum()),
        "positive_sample_annotation_matching_variant_rows": int(count_match),
        "frequency_equal_matrix_sum_variant_rows": int(
            source["Frequency"].eq(source[samples].sum(axis=1)).sum()
        ),
        "matrix_depth_to_supplement_final_reads_median_ratio": float((source_totals / final_reads).median()),
        "limitations": (
            "Unadjusted two-cohort stool 16S comparison; individual age/sex not available "
            "for Bowerman. Variable-region/taxonomy pipelines differ. No blood metabolites "
            "or shared participants. Publisher source matrix sums differ from supplemental "
            "final-read counts; use only source matrix counts for this analysis."
        ),
    }
    OUT.mkdir(exist_ok=True)
    combined.to_csv(OUT / "bowerman_data2873_genus_unadjusted.csv", index=False)
    overlap.to_csv(OUT / "bowerman_data2873_genus_overlap.csv", index=False)
    xcol = "beta_copd_minus_control_sd_bowerman"
    ycol = "beta_copd_minus_control_sd_data2873"
    fig, ax = plt.subplots(figsize=(6.4, 5.0))
    ax.axhline(0, color="#888888", lw=0.8)
    ax.axvline(0, color="#888888", lw=0.8)
    ax.scatter(overlap[xcol], overlap[ycol],
               c=np.where(overlap["same_direction"], "#2c6b8e", "#ad5148"),
               s=35, alpha=0.85)
    for label in ("Streptococcus", "Bacteroides"):
        hit = overlap.loc[overlap["genus"].eq(label)]
        if not hit.empty:
            offset = (-5, 8) if label == "Streptococcus" else (5, 5)
            ax.annotate(label, (hit.iloc[0][xcol], hit.iloc[0][ycol]),
                        xytext=offset, textcoords="offset points", fontsize=8,
                        ha="right" if label == "Streptococcus" else "left")
    ax.set(xlabel="Bowerman COPD−control estimate (within-cohort SD)",
           ylabel="DATA2873 COPD−control estimate (within-cohort SD)",
           title=f"{int(overlap['same_direction'].sum())}/{len(overlap)} genus directions concordant")
    fig.tight_layout()
    fig.savefig(OUT / "supplementary_figure_s4_bowerman_stool_transport.png", dpi=300)
    plt.close(fig)
    (OUT / "bowerman_stool_audit.json").write_text(
        json.dumps(audit, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps(audit, ensure_ascii=False, indent=2))
    print(overlap[["genus", "beta_copd_minus_control_sd_bowerman", "q_bh_within_cohort_bowerman",
                   "beta_copd_minus_control_sd_data2873", "q_bh_within_cohort_data2873",
                   "same_direction"]].head(12).to_string(index=False))


if __name__ == "__main__":
    main()
