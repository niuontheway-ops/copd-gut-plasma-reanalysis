"""Fetch a small public research file and print its provenance."""

import hashlib
import sys
import urllib.request
from pathlib import Path


def main() -> None:
    url, output = sys.argv[1], Path(sys.argv[2])
    limit = 25 * 1024 * 1024
    with urllib.request.urlopen(url, timeout=60) as response:
        announced = int(response.headers.get("Content-Length") or 0)
        if announced > limit:
            raise ValueError(f"File exceeds 25 MiB: {announced}")
        data = response.read(limit + 1)
        if len(data) > limit:
            raise ValueError("File exceeds 25 MiB")
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_bytes(data)
    print(f"url={url}\npath={output}\nbytes={len(data)}\nsha256={hashlib.sha256(data).hexdigest()}")


if __name__ == "__main__":
    main()
